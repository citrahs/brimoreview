import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

function cleanJsonString(text: string): string {
  return text.replace(/```json\n?|```/g, "").trim();
}

export interface Topic {
  name: string;
  sentiment: number; // 0 to 100
  frequency: number; // 0 to 100
}

export interface StoreData {
  platform: "Google Play Store" | "App Store";
  rating: number;
  reviewCount: string;
  keyPoints: string[];
  recommendations: string[];
  ratingDistribution: { stars: number; count: number }[];
  sentimentAnalysis: {
    positive: number;
    neutral: number;
    negative: number;
  };
  topics: Topic[];
}

export interface AnalyticsReport {
  summary: string;
  playStore: StoreData;
  appStore: StoreData;
  overallRecommendation: string;
}

export async function generateBRImoReport(): Promise<AnalyticsReport> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Analyze the current performance and user sentiment of the BRImo (BRI Mobile) app on both Google Play Store and Apple App Store.
    
    Provide a detailed report in Bahasa Indonesia including:
    1. Current average rating and approximate review count for both stores.
    2. A estimated rating distribution (1-5 stars) for both stores based on general sentiment.
    3. Key positive and negative points from recent user reviews for each platform.
    4. Sentiment Analysis: Percentage of positive, neutral, and negative sentiment in recent reviews.
    5. Topic Modeling: Identify the top 5 recurring topics (e.g., UI/UX, Security, Transaction Speed, Bug/Crash, Customer Service) and for each topic provide:
       - Name of the topic
       - Sentiment score for that specific topic (0-100)
       - Frequency/Importance score (0-100)
    6. Specific recommendations for future development for each platform.
    7. An overall summary of the app's standing.

    Use Google Search to find the most recent data. All text content in the JSON response must be in Bahasa Indonesia.
  `;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          playStore: {
            type: Type.OBJECT,
            properties: {
              platform: { type: Type.STRING },
              rating: { type: Type.NUMBER },
              reviewCount: { type: Type.STRING },
              keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
              recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
              ratingDistribution: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    stars: { type: Type.NUMBER },
                    count: { type: Type.NUMBER }
                  }
                }
              },
              sentimentAnalysis: {
                type: Type.OBJECT,
                properties: {
                  positive: { type: Type.NUMBER },
                  neutral: { type: Type.NUMBER },
                  negative: { type: Type.NUMBER }
                }
              },
              topics: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    sentiment: { type: Type.NUMBER },
                    frequency: { type: Type.NUMBER }
                  }
                }
              }
            }
          },
          appStore: {
            type: Type.OBJECT,
            properties: {
              platform: { type: Type.STRING },
              rating: { type: Type.NUMBER },
              reviewCount: { type: Type.STRING },
              keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
              recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
              ratingDistribution: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    stars: { type: Type.NUMBER },
                    count: { type: Type.NUMBER }
                  }
                }
              },
              sentimentAnalysis: {
                type: Type.OBJECT,
                properties: {
                  positive: { type: Type.NUMBER },
                  neutral: { type: Type.NUMBER },
                  negative: { type: Type.NUMBER }
                }
              },
              topics: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    sentiment: { type: Type.NUMBER },
                    frequency: { type: Type.NUMBER }
                  }
                }
              }
            }
          },
          overallRecommendation: { type: Type.STRING }
        },
        required: ["summary", "playStore", "appStore", "overallRecommendation"]
      }
    }
  });

  try {
    const text = response.text || "{}";
    return JSON.parse(cleanJsonString(text));
  } catch (e) {
    console.error("Failed to parse report JSON", e);
    throw new Error("Gagal memproses data dari AI. Silakan coba lagi.");
  }
}

export async function answerQuestion(question: string, report: AnalyticsReport): Promise<string> {
  const model = "gemini-3-flash-preview";
  const ai = getAI();
  const prompt = `
    Anda adalah asisten ahli analitik aplikasi. Berikut adalah data laporan analitik terbaru untuk aplikasi BRImo:
    
    RINGKASAN: ${report.summary}
    
    PLAY STORE:
    - Rating: ${report.playStore.rating}
    - Ulasan: ${report.playStore.reviewCount}
    - Poin Kunci: ${report.playStore.keyPoints.join(", ")}
    - Topik: ${report.playStore.topics.map(t => `${t.name} (Sentimen: ${t.sentiment}, Frekuensi: ${t.frequency})`).join(", ")}
    
    APP STORE:
    - Rating: ${report.appStore.rating}
    - Ulasan: ${report.appStore.reviewCount}
    - Poin Kunci: ${report.appStore.keyPoints.join(", ")}
    - Topik: ${report.appStore.topics.map(t => `${t.name} (Sentimen: ${t.sentiment}, Frekuensi: ${t.frequency})`).join(", ")}
    
    REKOMENDASI KESELURUHAN: ${report.overallRecommendation}
    
    PERTANYAAN PENGGUNA: "${question}"
    
    Berikan jawaban yang cerdas, ringkas, dan profesional dalam Bahasa Indonesia berdasarkan data di atas. Jika pertanyaan tidak relevan dengan data BRImo, sampaikan dengan sopan.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
    }
  });

  return response.text || "Maaf, saya tidak dapat menghasilkan jawaban saat ini.";
}
