import React, { useEffect, useState, useRef } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Legend
} from 'recharts';
import { 
  TrendingUp, 
  Star, 
  MessageSquare, 
  Lightbulb, 
  Smartphone, 
  Apple, 
  LayoutDashboard,
  Loader2,
  AlertCircle,
  ChevronRight,
  ArrowUpRight,
  Download,
  FileText,
  PieChart as PieChartIcon,
  Layers,
  Send,
  User,
  Bot,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { generateBRImoReport, AnalyticsReport, StoreData, Topic, answerQuestion } from './services/geminiService';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import jsPDF from 'jspdf';
import { toPng } from 'html-to-image';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const SENTIMENT_COLORS = {
  positive: '#10b981',
  neutral: '#94a3b8',
  negative: '#ef4444'
};

const ChatBubble = ({ message, isBot }: { message: string, isBot: boolean }) => (
  <motion.div
    initial={{ opacity: 0, x: isBot ? -10 : 10 }}
    animate={{ opacity: 1, x: 0 }}
    className={cn(
      "flex gap-3 mb-4",
      isBot ? "flex-row" : "flex-row-reverse"
    )}
  >
    <div className={cn(
      "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
      isBot ? "bg-indigo-100 text-indigo-600" : "bg-slate-100 text-slate-600"
    )}>
      {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
    </div>
    <div className={cn(
      "max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed",
      isBot ? "bg-white border border-slate-200 text-slate-700" : "bg-indigo-600 text-white"
    )}>
      {message}
    </div>
  </motion.div>
);

const Card = ({ children, className, title, icon: Icon }: { children: React.ReactNode, className?: string, title?: string, icon?: any }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className={cn("bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden", className)}
  >
    {title && (
      <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2 bg-slate-50/50">
        {Icon && <Icon className="w-4 h-4 text-slate-500" />}
        <h3 className="font-semibold text-slate-800 text-sm uppercase tracking-wider">{title}</h3>
      </div>
    )}
    <div className="p-6">
      {children}
    </div>
  </motion.div>
);

const PlatformHeader = ({ data }: { data: StoreData }) => {
  const isPlayStore = data.platform.includes('Google');
  return (
    <div className="flex items-center justify-between mb-8">
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-12 h-12 rounded-xl flex items-center justify-center shadow-inner",
          isPlayStore ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-800"
        )}>
          {isPlayStore ? <Smartphone className="w-6 h-6" /> : <Apple className="w-6 h-6" />}
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900">{data.platform}</h2>
          <div className="flex items-center gap-2 text-slate-500 text-sm">
            <span className="flex items-center gap-1 font-medium text-amber-500">
              <Star className="w-4 h-4 fill-current" /> {data.rating.toFixed(1)}
            </span>
            <span>•</span>
            <span>{data.reviewCount} Ulasan</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const SentimentChart = ({ data }: { data: StoreData['sentimentAnalysis'] }) => {
  const chartData = [
    { name: 'Positif', value: data.positive, color: SENTIMENT_COLORS.positive },
    { name: 'Netral', value: data.neutral, color: SENTIMENT_COLORS.neutral },
    { name: 'Negatif', value: data.negative, color: SENTIMENT_COLORS.negative },
  ];

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
          />
          <Legend verticalAlign="bottom" height={36}/>
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

const TopicChart = ({ topics }: { topics: Topic[] }) => {
  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={topics}>
          <PolarGrid stroke="#e2e8f0" />
          <PolarAngleAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar
            name="Sentimen"
            dataKey="sentiment"
            stroke="#6366f1"
            fill="#6366f1"
            fillOpacity={0.6}
          />
          <Radar
            name="Frekuensi"
            dataKey="frequency"
            stroke="#10b981"
            fill="#10b981"
            fillOpacity={0.4}
          />
          <Tooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
          />
          <Legend />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default function App() {
  const [report, setReport] = useState<AnalyticsReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<{ text: string, isBot: boolean }[]>([
    { text: "Halo! Saya asisten analitik BRImo. Ada yang ingin Anda tanyakan tentang laporan ini?", isBot: true }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isTyping || !report) return;

    const userMsg = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { text: userMsg, isBot: false }]);
    setIsTyping(true);

    try {
      const response = await answerQuestion(userMsg, report);
      setChatMessages(prev => [...prev, { text: response, isBot: true }]);
    } catch (err) {
      setChatMessages(prev => [...prev, { text: "Maaf, terjadi kesalahan saat memproses pertanyaan Anda.", isBot: true }]);
    } finally {
      setIsTyping(false);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = await generateBRImoReport();
        setReport(data);
      } catch (err) {
        setError('Gagal memuat laporan analitik. Silakan coba lagi nanti.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleShare = async () => {
    if (!report) return;
    const shareText = `Ikhtisar Performa BRImo: Rating Rata-rata ${((report.playStore.rating + report.appStore.rating) / 2).toFixed(1)}/5.0. Analisis lengkap tersedia di dasbor analitik.`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Analitik BRImo',
          text: shareText,
          url: window.location.href,
        });
      } catch (err) {
        console.error('Share failed:', err);
      }
    } else {
      try {
        await navigator.clipboard.writeText(`${shareText} ${window.location.href}`);
        alert('Tautan dan ringkasan telah disalin ke papan klip!');
      } catch (err) {
        console.error('Copy failed:', err);
      }
    }
  };

  const exportToPDF = async () => {
    if (!reportRef.current) return;
    
    try {
      setIsExporting(true);
      
      // Small delay to ensure all animations and charts are settled
      await new Promise(resolve => setTimeout(resolve, 800));

      // html-to-image is much better at handling modern CSS like oklch/oklab
      // as it uses the browser's native SVG rendering engine.
      const dataUrl = await toPng(reportRef.current, {
        quality: 0.95,
        pixelRatio: 2,
        backgroundColor: '#f8fafc',
        style: {
          transform: 'scale(1)',
        }
      });
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      // Calculate dimensions to fit A4
      const img = new Image();
      img.src = dataUrl;
      await new Promise((resolve) => (img.onload = resolve));
      
      const imgWidth = pdfWidth;
      const imgHeight = (img.height * imgWidth) / img.width;
      
      // If content is longer than one page, it will be scaled to fit
      // For a more advanced implementation, we could split into multiple pages
      pdf.addImage(dataUrl, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`Laporan_Analitik_BRImo_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (err) {
      console.error('PDF export failed:', err);
      alert('Gagal mengekspor PDF. Silakan coba lagi.');
    } finally {
      setIsExporting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        >
          <Loader2 className="w-12 h-12 text-indigo-600" />
        </motion.div>
        <p className="mt-4 text-slate-600 font-medium animate-pulse">Menganalisis data toko dan menghasilkan wawasan...</p>
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center border border-red-100">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-900 mb-2">Analisis Gagal</h2>
          <p className="text-slate-600 mb-6">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
          >
            Coba Lagi
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <LayoutDashboard className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">Analitik BRImo</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full">
              Laporan Langsung • {new Date().toLocaleDateString('id-ID')}
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" ref={reportRef}>
        {/* Summary Section */}
        <section className="mb-12">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-3xl p-8 text-white shadow-xl shadow-indigo-200"
          >
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-5 h-5 text-indigo-200" />
                  <span className="text-indigo-100 font-semibold uppercase tracking-wider text-sm">Ringkasan Eksekutif</span>
                </div>
                <h2 className="text-3xl font-bold mb-4 leading-tight">Ikhtisar Performa BRImo</h2>
                <div className="prose prose-invert max-w-none text-indigo-50/90 leading-relaxed">
                  <ReactMarkdown>{report.summary}</ReactMarkdown>
                </div>
              </div>
              <div className="w-full md:w-72 bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
                <div className="space-y-6">
                  <div>
                    <p className="text-indigo-200 text-xs font-bold uppercase tracking-widest mb-1">Rating Rata-rata</p>
                    <p className="text-4xl font-bold">
                      {((report.playStore.rating + report.appStore.rating) / 2).toFixed(1)}
                      <span className="text-xl text-indigo-300 ml-1">/ 5.0</span>
                    </p>
                  </div>
                  <div className="h-px bg-white/10" />
                  <div>
                    <p className="text-indigo-200 text-xs font-bold uppercase tracking-widest mb-1">Jangkauan Total</p>
                    <p className="text-2xl font-bold">Multi-Platform</p>
                    <p className="text-indigo-200 text-sm">100Jt+ Unduhan</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Platform Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Play Store Analysis */}
          <div className="space-y-8">
            <PlatformHeader data={report.playStore} />
            
            <div className="grid grid-cols-1 gap-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card title="Distribusi Rating" icon={BarChart}>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[...(report.playStore.ratingDistribution || [])].sort((a, b) => b.stars - a.stars)} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                        <XAxis type="number" hide />
                        <YAxis dataKey="stars" type="category" width={30} tick={{fontSize: 12, fontWeight: 600}} />
                        <Tooltip 
                          cursor={{fill: '#f8fafc'}}
                          contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                        />
                        <Bar dataKey="count" fill="#10b981" radius={[0, 4, 4, 0]} barSize={20} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card title="Analisis Sentimen" icon={PieChartIcon}>
                  <SentimentChart data={report.playStore.sentimentAnalysis} />
                </Card>
              </div>

              <Card title="Pemodelan Topik (Sentimen vs Frekuensi)" icon={Layers}>
                <TopicChart topics={report.playStore.topics} />
              </Card>

              <Card title="Poin Kunci Ulasan" icon={MessageSquare}>
                <ul className="space-y-4">
                  {report.playStore.keyPoints.map((point, idx) => (
                    <li key={idx} className="flex gap-3 items-start group">
                      <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0 group-hover:scale-125 transition-transform" />
                      <span className="text-slate-600 text-sm leading-relaxed">{point}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              <Card title="Rekomendasi Pengembangan" icon={Lightbulb} className="border-emerald-100 bg-emerald-50/30">
                <div className="space-y-4">
                  {report.playStore.recommendations.map((rec, idx) => (
                    <div key={idx} className="flex gap-3 bg-white p-4 rounded-xl border border-emerald-100 shadow-sm">
                      <div className="bg-emerald-100 p-2 rounded-lg shrink-0">
                        <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                      </div>
                      <p className="text-slate-700 text-sm font-medium">{rec}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>

          {/* App Store Analysis */}
          <div className="space-y-8">
            <PlatformHeader data={report.appStore} />
            
            <div className="grid grid-cols-1 gap-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card title="Distribusi Rating" icon={BarChart}>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[...(report.appStore.ratingDistribution || [])].sort((a, b) => b.stars - a.stars)} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                        <XAxis type="number" hide />
                        <YAxis dataKey="stars" type="category" width={30} tick={{fontSize: 12, fontWeight: 600}} />
                        <Tooltip 
                          cursor={{fill: '#f8fafc'}}
                          contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                        />
                        <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={20} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card title="Analisis Sentimen" icon={PieChartIcon}>
                  <SentimentChart data={report.appStore.sentimentAnalysis} />
                </Card>
              </div>

              <Card title="Pemodelan Topik (Sentimen vs Frekuensi)" icon={Layers}>
                <TopicChart topics={report.appStore.topics} />
              </Card>

              <Card title="Poin Kunci Ulasan" icon={MessageSquare}>
                <ul className="space-y-4">
                  {report.appStore.keyPoints.map((point, idx) => (
                    <li key={idx} className="flex gap-3 items-start group">
                      <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0 group-hover:scale-125 transition-transform" />
                      <span className="text-slate-600 text-sm leading-relaxed">{point}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              <Card title="Rekomendasi Pengembangan" icon={Lightbulb} className="border-blue-100 bg-blue-50/30">
                <div className="space-y-4">
                  {report.appStore.recommendations.map((rec, idx) => (
                    <div key={idx} className="flex gap-3 bg-white p-4 rounded-xl border border-blue-100 shadow-sm">
                      <div className="bg-blue-100 p-2 rounded-lg shrink-0">
                        <ArrowUpRight className="w-4 h-4 text-blue-600" />
                      </div>
                      <p className="text-slate-700 text-sm font-medium">{rec}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>

        {/* Final Recommendation */}
        <section className="mt-12">
          <Card className="bg-slate-900 text-white border-none shadow-2xl overflow-visible relative">
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest shadow-lg">
              Peta Jalan Strategis
            </div>
            <div className="pt-4">
              <h3 className="text-2xl font-bold mb-6 text-center">Strategi Pengembangan Masa Depan</h3>
              <div className="prose prose-invert max-w-none">
                <ReactMarkdown>{report.overallRecommendation}</ReactMarkdown>
              </div>
              <div className="mt-10 flex flex-wrap gap-4 justify-center">
                <button 
                  onClick={exportToPDF}
                  disabled={isExporting}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl font-bold transition-all transform hover:scale-105 disabled:opacity-50 disabled:scale-100"
                >
                  {isExporting ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Download className="w-5 h-5" />
                  )}
                  {isExporting ? 'Mengekspor...' : 'Ekspor Laporan Lengkap'}
                </button>
                <button 
                  onClick={handleShare}
                  className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-8 py-3 rounded-xl font-bold border border-white/20 transition-all"
                >
                  Bagikan Wawasan <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </Card>
        </section>
      </main>

      <footer className="bg-white border-t border-slate-200 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-slate-400 text-sm">
            © {new Date().getFullYear()} Mesin Laporan Analitik BRImo. Didukung oleh Gemini AI.
          </p>
          <p className="text-slate-300 text-xs mt-2">
            Data disintesis dari ulasan toko publik dan metrik performa.
          </p>
        </div>
      </footer>

      {/* Floating Chat Button */}
      <div className="fixed bottom-8 right-8 z-50">
        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="absolute bottom-20 right-0 w-80 md:w-96 h-[500px] bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden"
            >
              {/* Chat Header */}
              <div className="bg-indigo-600 p-4 text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  <span className="font-bold">Asisten Analitik BRImo</span>
                </div>
                <button 
                  onClick={() => setIsChatOpen(false)}
                  className="p-1 hover:bg-white/20 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto p-4 bg-slate-50">
                {chatMessages.map((msg, idx) => (
                  <ChatBubble key={idx} message={msg.text} isBot={msg.isBot} />
                ))}
                {isTyping && (
                  <div className="flex gap-2 items-center text-slate-400 text-xs ml-11 mb-4">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    <span>Asisten sedang mengetik...</span>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-100 bg-white">
                <div className="relative">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Tanyakan sesuatu tentang laporan..."
                    className="w-full pl-4 pr-12 py-3 bg-slate-100 border-none rounded-2xl text-sm focus:ring-2 focus:ring-indigo-500 transition-all"
                  />
                  <button
                    type="submit"
                    disabled={!chatInput.trim() || isTyping}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-all"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsChatOpen(!isChatOpen)}
          className={cn(
            "w-16 h-16 rounded-full shadow-2xl flex items-center justify-center text-white transition-all",
            isChatOpen ? "bg-slate-800 rotate-90" : "bg-indigo-600"
          )}
        >
          {isChatOpen ? <X className="w-8 h-8" /> : <MessageSquare className="w-8 h-8" />}
        </motion.button>
      </div>
    </div>
  );
}
